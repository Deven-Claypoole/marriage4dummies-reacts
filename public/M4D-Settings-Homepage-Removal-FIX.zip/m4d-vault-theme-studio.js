/* M4D Vault Theme Studio — data access only through scoped Supabase RPCs. */
(()=>{'use strict';
const db=window.supabaseClient,$=id=>document.getElementById(id);
if(!db?.auth || !$('m4dExclusiveThemes'))return;
const fields=['name','description','bg','surface','accent','accent2','fg','pattern','code','published'];
const defaults={name:'M4D Signature',description:'A member-exclusive M4D look',bg:'#10111b',surface:'#232337',accent:'#ef355d',accent2:'#9a66f7',fg:'#ffffff',pattern:'glow',code:'',published:false};
let currentUser=null,admin=false,editId=null,items=[],activeId=null;
const msg=(id,v)=>{const el=$(id);if(el)el.textContent=v};
const validColor=v=>/^#[0-9a-fA-F]{6}$/.test(v);
const getForm=()=>Object.fromEntries(fields.map(f=>[f,f==='published'?$('m4dStudio_'+f).checked:$('m4dStudio_'+f).value]));
function setForm(d){for(const f of fields){const el=$('m4dStudio_'+f);if(el){if(f==='published')el.checked=Boolean(d[f]);else el.value=d[f]??defaults[f]}}preview()}
function preview(){const el=$('m4dThemeStudioPreview');if(!el)return;const d=getForm();for(const k of ['bg','surface','accent','accent2','fg'])el.style.setProperty('--preview-'+k,validColor(d[k])?d[k]:defaults[k]);$('m4dThemeStudioPreviewTitle').textContent=d.name||'Your design';}
function clearApplied(){document.documentElement.classList.remove('m4d-exclusive-theme-active');delete document.documentElement.dataset.exclusivePattern;try{localStorage.removeItem('m4d_exclusive_theme_id')}catch{}}
function apply(t){if(!t?.unlocked){msg('m4dExclusiveStatus','Unlock this theme in the Vault first.');return}for(const key of ['bg','surface','accent','accent2','fg']){if(!validColor(t[key]))return;document.documentElement.style.setProperty('--exclusive-'+key,t[key])}document.documentElement.dataset.exclusivePattern=t.pattern||'none';document.documentElement.classList.add('m4d-exclusive-theme-active');activeId=t.id;try{localStorage.setItem('m4d_exclusive_theme_id',t.id)}catch{}}
async function saveSelection(id){
  const {data:{user},error:e}=await db.auth.getUser();
  if(e||!user){msg('m4dExclusiveStatus','Sign in to equip themes.');return;}
  const t=items.find(x=>x.id===id&&x.unlocked);
  if(!t){msg('m4dExclusiveStatus','This theme must be unlocked first.');return;}
  msg('m4dExclusiveStatus','Saving your theme to your account…');
  // Update first, then insert if no preference row exists. Preserve favorite categories.
  let result=await db.from('m4d_next_preferences').update({theme:'classic',custom_theme_id:id,updated_at:new Date().toISOString()}).eq('user_id',user.id).select('custom_theme_id');
  if(!result.error&&(!result.data||result.data.length===0)){
    result=await db.from('m4d_next_preferences').insert({user_id:user.id,theme:'classic',custom_theme_id:id}).select('custom_theme_id');
  }
  if(result.error){msg('m4dExclusiveStatus','Could not save theme: '+result.error.message);return;}
  // Re-read from Supabase: do not claim success unless the database confirms the selection.
  const check=await db.from('m4d_next_preferences').select('custom_theme_id').eq('user_id',user.id).maybeSingle();
  if(check.error||check.data?.custom_theme_id!==id){
    msg('m4dExclusiveStatus','Theme save could not be verified: '+(check.error?.message||'selection not stored')+'.');return;
  }
  window.m4dSavedExclusiveThemeId=id;
  apply(t);
  msg('m4dExclusiveStatus',t.name+' saved to your account. Refresh to confirm it stays equipped.');
}
function card(t){const box=document.createElement('article');box.className='m4d-vault-theme-card';const sw=document.createElement('span');sw.className='m4d-vault-theme-swatch';sw.style.setProperty('--sample-bg',validColor(t.bg)?t.bg:'#13141a');sw.style.setProperty('--sample-accent',validColor(t.accent)?t.accent:'#e43');sw.style.setProperty('--sample-accent2',validColor(t.accent2)?t.accent2:'#93f');const heading=document.createElement('strong');heading.textContent=t.name;const desc=document.createElement('small');desc.textContent=t.description||'';const b=document.createElement('button');b.type='button';b.textContent=t.unlocked?'Equip theme':'🔒 Vault locked';b.disabled=!t.unlocked;b.onclick=()=>saveSelection(t.id);box.append(sw,heading,desc,b);if(admin){const edit=document.createElement('button');edit.textContent='Edit as admin';edit.type='button';edit.onclick=()=>{editId=t.id;setForm({...t,code:''});msg('m4dThemeStudioStatus','Editing '+t.name+'. Leave unlock code blank to keep the old code.');$('m4dThemeStudio').scrollIntoView({behavior:'smooth'});};box.append(edit)}return box;}
function render(){const gallery=$('m4dExclusiveThemeGallery');gallery.replaceChildren();if(!items.length){gallery.textContent='No exclusive themes published yet. Admins can create the first one below.';return;}items.forEach(t=>gallery.append(card(t)));}
async function refresh(){if(!currentUser){msg('m4dExclusiveStatus','Sign in to see your unlocked themes.');return;}const {data,error}=await db.rpc('m4d_theme_catalog');if(error){msg('m4dExclusiveStatus','Theme catalog unavailable: '+error.message+' (check SQL setup).');return;}items=data||[];render();const {data:pr,error:readError}=await db.from('m4d_next_preferences').select('custom_theme_id').eq('user_id',currentUser.id).maybeSingle();if(readError){msg('m4dExclusiveStatus','Could not load saved theme: '+readError.message);return;}const selected=pr?.custom_theme_id||null;const t=items.find(x=>x.id===selected&&x.unlocked);if(t){window.m4dSavedExclusiveThemeId=selected;apply(t)}else{window.m4dSavedExclusiveThemeId=null;clearApplied()}msg('m4dExclusiveStatus',items.filter(x=>x.unlocked).length+' exclusive theme(s) unlocked.');}
async function auth(){const {data,error}=await db.auth.getUser();currentUser=error?null:data.user;admin=false;if(currentUser){const result=await db.rpc('m4d_is_admin');admin=result.data===true;}const studio=$('m4dThemeStudio');studio.hidden=!admin;await refresh();}
$('m4dVaultThemeUnlockForm').addEventListener('submit',async e=>{e.preventDefault();const input=$('m4dVaultThemeCode'),code=input.value,btn=$('m4dVaultThemeUnlockButton');if(!currentUser){msg('m4dVaultThemeUnlockStatus','Sign in first.');return;}btn.disabled=true;msg('m4dVaultThemeUnlockStatus','Checking your code…');try{const {data,error}=await db.rpc('m4d_theme_unlock',{p_code:code});if(error)throw error;msg('m4dVaultThemeUnlockStatus',data.message||'Check complete.');if(data.ok){input.value='';await refresh();document.getElementById('m4dExclusiveThemes')?.scrollIntoView({behavior:'smooth'});}}catch(err){msg('m4dVaultThemeUnlockStatus','Unlock failed: '+err.message)}finally{btn.disabled=false}});
$('m4dThemeStudioForm').addEventListener('input',preview);
$('m4dThemeStudioForm').addEventListener('submit',async e=>{e.preventDefault();if(!admin)return;const d=getForm();if(!editId&&d.code.length<8){msg('m4dThemeStudioStatus','Use an unlock code of at least 8 characters.');return;}const btn=$('m4dStudioSave');btn.disabled=true;msg('m4dThemeStudioStatus','Saving theme on the server…');try{const {error}=await db.rpc('m4d_theme_admin_save',{p_name:d.name,p_description:d.description,p_bg:d.bg,p_surface:d.surface,p_accent:d.accent,p_accent2:d.accent2,p_fg:d.fg,p_pattern:d.pattern,p_code:d.code,p_published:d.published,p_id:editId});if(error)throw error;editId=null;setForm(defaults);msg('m4dThemeStudioStatus','Theme saved! Published themes appear in the Vault collection.');await refresh();}catch(err){msg('m4dThemeStudioStatus','Could not save: '+err.message)}finally{btn.disabled=false}});
$('m4dStudioNew').addEventListener('click',()=>{editId=null;setForm(defaults);msg('m4dThemeStudioStatus','New theme ready to design.');});
$('m4dPlusthemeList')?.addEventListener('click',e=>{if(e.target.closest('button')){clearApplied();activeId=null;}});
// Existing controller saves a builtin theme; custom selection must be cleared too.
const controller=document.getElementById('m4d-community-plus-controller');if(controller){const txt=controller.textContent; if(!txt.includes('custom_theme_id:null')) console.warn('Builtin themes should clear custom_theme_id when saving.');}
db.auth.onAuthStateChange(()=>setTimeout(auth,120));setForm(defaults);setTimeout(auth,250);
})();
